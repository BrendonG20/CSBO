import { useState, useEffect } from 'react'
import { Button } from '@/components/ui/button.jsx'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card.jsx'
import { Badge } from '@/components/ui/badge.jsx'
import { Input } from '@/components/ui/input.jsx'
import { Textarea } from '@/components/ui/textarea.jsx'
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select.jsx'
import { 
  Shield, 
  TrendingUp, 
  Users, 
  FileText, 
  CheckCircle, 
  ArrowRight, 
  Mail, 
  Phone, 
  MapPin,
  Building,
  DollarSign,
  BarChart3,
  Globe,
  Award,
  Star,
  Menu,
  X
} from 'lucide-react'
import csboLogo from './assets/csbo_logo.png'
import './App.css'

function App() {
  const [isMenuOpen, setIsMenuOpen] = useState(false)
  const [activeSection, setActiveSection] = useState('home')

  useEffect(() => {
    const handleScroll = () => {
      const sections = ['home', 'about', 'services', 'how-it-works', 'contact']
      const scrollPosition = window.scrollY + 100

      sections.forEach(section => {
        const element = document.getElementById(section)
        if (element) {
          const offsetTop = element.offsetTop
          const offsetHeight = element.offsetHeight
          if (scrollPosition >= offsetTop && scrollPosition < offsetTop + offsetHeight) {
            setActiveSection(section)
          }
        }
      })
    }

    window.addEventListener('scroll', handleScroll)
    return () => window.removeEventListener('scroll', handleScroll)
  }, [])

  const scrollToSection = (sectionId) => {
    const element = document.getElementById(sectionId)
    if (element) {
      element.scrollIntoView({ behavior: 'smooth' })
    }
    setIsMenuOpen(false)
  }

  const services = [
    {
      title: "Syndicate Starter",
      subtitle: "Basic Package",
      price: "Flat Fee",
      description: "Perfect for first-time syndicators launching single-asset deals",
      features: [
        "Fund Setup (Reg D)",
        "Investor Onboarding", 
        "Basic Reporting",
        "Legal Documentation"
      ],
      ideal: "First-time syndicators, single-asset deals",
      popular: false
    },
    {
      title: "Growth Fund",
      subtitle: "Premium Package", 
      price: "Monthly Retainer",
      description: "Comprehensive support for established sponsors with multi-asset funds",
      features: [
        "All Starter Services",
        "Advanced Tax Handling (K-1s)",
        "Ongoing Distributions",
        "Blue Sky Compliance",
        "DST Structuring (1031)"
      ],
      ideal: "Established sponsors, multi-asset funds",
      popular: true
    },
    {
      title: "Enterprise Fund",
      subtitle: "Enterprise Package",
      price: "Custom Pricing",
      description: "Full-service solution for large private equity firms and complex structures",
      features: [
        "All Growth Services",
        "Offshore Structuring",
        "Bond Market Exits",
        "Dedicated Account Manager",
        "M&A Advisory"
      ],
      ideal: "Large private equity firms, complex global structures",
      popular: false
    }
  ]

  const testimonials = [
    {
      name: "Sarah Johnson",
      title: "Managing Partner, Apex Real Estate",
      content: "CSBO transformed our operations. Their compliance-first approach gave us confidence to scale from single deals to a multi-asset fund.",
      rating: 5
    },
    {
      name: "Michael Chen",
      title: "Founder, Pacific Capital Group",
      content: "The team's expertise in complex structuring helped us optimize our tax efficiency while maintaining full regulatory compliance.",
      rating: 5
    },
    {
      name: "Jennifer Martinez",
      title: "Principal, Heritage Investment Partners",
      content: "Outstanding service and attention to detail. CSBO handles everything so we can focus on what we do best - finding great deals.",
      rating: 5
    }
  ]

  return (
    <div className="min-h-screen bg-background scroll-smooth">
      {/* Navigation */}
      <nav className="fixed top-0 w-full bg-white/95 backdrop-blur-sm border-b border-border z-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            <div className="flex items-center space-x-3">
              <img src={csboLogo} alt="CSBO Logo" className="h-10 w-10" />
              <div>
                <div className="text-xl font-bold text-primary">CSBO</div>
                <div className="text-xs text-muted-foreground">Capital Stack Back Office</div>
              </div>
            </div>
            
            {/* Desktop Navigation */}
            <div className="hidden md:flex items-center space-x-8">
              {['home', 'about', 'services', 'how-it-works', 'contact'].map((section) => (
                <button
                  key={section}
                  onClick={() => scrollToSection(section)}
                  className={`text-sm font-medium transition-colors hover:text-primary ${
                    activeSection === section ? 'text-primary' : 'text-muted-foreground'
                  }`}
                >
                  {section.split('-').map(word => word.charAt(0).toUpperCase() + word.slice(1)).join(' ')}
                </button>
              ))}
              <Button onClick={() => scrollToSection('contact')} className="btn-primary">
                Get Started
              </Button>
            </div>

            {/* Mobile menu button */}
            <div className="md:hidden">
              <Button
                variant="ghost"
                size="sm"
                onClick={() => setIsMenuOpen(!isMenuOpen)}
              >
                {isMenuOpen ? <X className="h-6 w-6" /> : <Menu className="h-6 w-6" />}
              </Button>
            </div>
          </div>
        </div>

        {/* Mobile Navigation */}
        {isMenuOpen && (
          <div className="md:hidden bg-white border-t border-border">
            <div className="px-2 pt-2 pb-3 space-y-1">
              {['home', 'about', 'services', 'how-it-works', 'contact'].map((section) => (
                <button
                  key={section}
                  onClick={() => scrollToSection(section)}
                  className="block w-full text-left px-3 py-2 text-base font-medium text-muted-foreground hover:text-primary"
                >
                  {section.split('-').map(word => word.charAt(0).toUpperCase() + word.slice(1)).join(' ')}
                </button>
              ))}
            </div>
          </div>
        )}
      </nav>

      {/* Hero Section */}
      <section id="home" className="pt-16 hero-gradient text-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-20">
          <div className="text-center animate-fade-in">
            <h1 className="text-4xl md:text-6xl font-bold mb-6">
              Your Capital Stack
              <span className="block text-accent">Architect™</span>
            </h1>
            <p className="text-xl md:text-2xl mb-8 text-gray-200 max-w-3xl mx-auto">
              The indispensable architect of your investment success. We design, build, and manage 
              the complex financial infrastructure that underpins your real estate and private equity ventures.
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <Button 
                size="lg" 
                className="btn-secondary text-primary hover:text-primary"
                onClick={() => scrollToSection('services')}
              >
                Explore Services <ArrowRight className="ml-2 h-5 w-5" />
              </Button>
              <Button 
                size="lg" 
                variant="outline" 
                className="border-white text-white hover:bg-white hover:text-primary"
                onClick={() => scrollToSection('contact')}
              >
                Schedule Consultation
              </Button>
            </div>
          </div>
        </div>
      </section>

      {/* About Section */}
      <section id="about" className="py-20 bg-gray-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-3xl md:text-4xl font-bold text-primary mb-4">
              Who We Serve
            </h2>
            <p className="text-xl text-muted-foreground max-w-3xl mx-auto">
              CSBO's services are tailored to meet the unique needs of a diverse clientele 
              within the alternative investment space.
            </p>
          </div>

          <div className="grid md:grid-cols-3 gap-8 mb-16">
            <Card className="service-card animate-slide-in-left">
              <CardHeader>
                <Building className="h-12 w-12 text-primary mb-4" />
                <CardTitle>Real Estate Sponsors</CardTitle>
                <CardDescription>
                  From first-time syndicators to established operators managing large portfolios
                </CardDescription>
              </CardHeader>
              <CardContent>
                <p className="text-sm text-muted-foreground">
                  We provide the administrative backbone that allows sponsors to scale operations 
                  and attract institutional capital.
                </p>
              </CardContent>
            </Card>

            <Card className="service-card animate-fade-in">
              <CardHeader>
                <TrendingUp className="h-12 w-12 text-primary mb-4" />
                <CardTitle>Private Equity Managers</CardTitle>
                <CardDescription>
                  Supporting fund structuring and administration with regulatory compliance
                </CardDescription>
              </CardHeader>
              <CardContent>
                <p className="text-sm text-muted-foreground">
                  Ensuring compliance with all regulatory requirements and providing sophisticated 
                  reporting tools that investors demand.
                </p>
              </CardContent>
            </Card>

            <Card className="service-card animate-slide-in-right">
              <CardHeader>
                <Users className="h-12 w-12 text-primary mb-4" />
                <CardTitle>Accredited Investors</CardTitle>
                <CardDescription>
                  High-net-worth individuals and family offices seeking optimal structures
                </CardDescription>
              </CardHeader>
              <CardContent>
                <p className="text-sm text-muted-foreground">
                  Tax-efficient and asset-protected investment holdings to preserve and grow 
                  wealth across generations.
                </p>
              </CardContent>
            </Card>
          </div>

          {/* Value Propositions */}
          <div className="grid md:grid-cols-3 gap-8">
            <div className="text-center">
              <Shield className="h-16 w-16 text-primary mx-auto mb-4 feature-icon" />
              <h3 className="text-xl font-semibold mb-2">End-to-End Support</h3>
              <p className="text-muted-foreground">
                Comprehensive turnkey solutions covering every stage of the fund lifecycle
              </p>
            </div>
            <div className="text-center">
              <Award className="h-16 w-16 text-primary mx-auto mb-4 feature-icon" />
              <h3 className="text-xl font-semibold mb-2">Compliance-First</h3>
              <p className="text-muted-foreground">
                Proactive compliance approach protecting you and your investors from risks
              </p>
            </div>
            <div className="text-center">
              <Globe className="h-16 w-16 text-primary mx-auto mb-4 feature-icon" />
              <h3 className="text-xl font-semibold mb-2">Globally Scalable</h3>
              <p className="text-muted-foreground">
                International structuring expertise optimizing tax efficiency and asset protection
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* Services Section */}
      <section id="services" className="py-20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-3xl md:text-4xl font-bold text-primary mb-4">
              Tiered Service Packages
            </h2>
            <p className="text-xl text-muted-foreground max-w-3xl mx-auto">
              Choose the right level of support for your business, from first syndication 
              to large multi-fund enterprise.
            </p>
          </div>

          <div className="grid md:grid-cols-3 gap-8">
            {services.map((service, index) => (
              <Card key={index} className={`service-card relative ${service.popular ? 'border-primary' : ''}`}>
                {service.popular && (
                  <Badge className="absolute -top-3 left-1/2 transform -translate-x-1/2 bg-primary">
                    Most Popular
                  </Badge>
                )}
                <CardHeader>
                  <CardTitle className="text-2xl">{service.title}</CardTitle>
                  <CardDescription className="text-lg font-medium text-primary">
                    {service.subtitle}
                  </CardDescription>
                  <div className="text-3xl font-bold text-primary">{service.price}</div>
                  <p className="text-sm text-muted-foreground">{service.description}</p>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3 mb-6">
                    {service.features.map((feature, idx) => (
                      <div key={idx} className="flex items-center">
                        <CheckCircle className="h-5 w-5 text-green-500 mr-3 flex-shrink-0" />
                        <span className="text-sm">{feature}</span>
                      </div>
                    ))}
                  </div>
                  <div className="text-xs text-muted-foreground mb-4">
                    <strong>Ideal for:</strong> {service.ideal}
                  </div>
                  <Button 
                    className={service.popular ? "btn-primary w-full" : "btn-secondary w-full"}
                    onClick={() => scrollToSection('contact')}
                  >
                    Get Started
                  </Button>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* How It Works Section */}
      <section id="how-it-works" className="py-20 bg-gray-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-3xl md:text-4xl font-bold text-primary mb-4">
              How It Works
            </h2>
            <p className="text-xl text-muted-foreground max-w-3xl mx-auto">
              Our streamlined process ensures your fund is structured, launched, and managed 
              with precision and professionalism.
            </p>
          </div>

          <div className="grid md:grid-cols-4 gap-8">
            {[
              {
                step: "01",
                title: "Consultation",
                description: "We analyze your investment strategy and structure requirements",
                icon: <Users className="h-8 w-8" />
              },
              {
                step: "02", 
                title: "Structuring",
                description: "Design optimal fund structure with complete legal documentation",
                icon: <FileText className="h-8 w-8" />
              },
              {
                step: "03",
                title: "Launch",
                description: "Handle investor onboarding, compliance, and fund activation",
                icon: <TrendingUp className="h-8 w-8" />
              },
              {
                step: "04",
                title: "Management",
                description: "Ongoing administration, reporting, and compliance management",
                icon: <BarChart3 className="h-8 w-8" />
              }
            ].map((item, index) => (
              <div key={index} className="text-center">
                <div className="bg-primary text-white rounded-full w-16 h-16 flex items-center justify-center mx-auto mb-4">
                  {item.icon}
                </div>
                <div className="text-sm font-bold text-primary mb-2">STEP {item.step}</div>
                <h3 className="text-xl font-semibold mb-2">{item.title}</h3>
                <p className="text-muted-foreground text-sm">{item.description}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Testimonials */}
      <section className="py-20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-3xl md:text-4xl font-bold text-primary mb-4">
              What Our Clients Say
            </h2>
          </div>

          <div className="grid md:grid-cols-3 gap-8">
            {testimonials.map((testimonial, index) => (
              <Card key={index} className="service-card">
                <CardHeader>
                  <div className="flex items-center mb-2">
                    {[...Array(testimonial.rating)].map((_, i) => (
                      <Star key={i} className="h-5 w-5 text-yellow-400 fill-current" />
                    ))}
                  </div>
                  <CardDescription className="text-base italic">
                    "{testimonial.content}"
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="font-semibold">{testimonial.name}</div>
                  <div className="text-sm text-muted-foreground">{testimonial.title}</div>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Contact Section */}
      <section id="contact" className="py-20 bg-gray-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-3xl md:text-4xl font-bold text-primary mb-4">
              Get Started Today
            </h2>
            <p className="text-xl text-muted-foreground max-w-3xl mx-auto">
              Ready to optimize your capital stack? Contact us for a consultation.
            </p>
          </div>

          <div className="grid md:grid-cols-2 gap-12">
            <div>
              <h3 className="text-2xl font-semibold mb-6">Contact Information</h3>
              <div className="space-y-4">
                <div className="flex items-center">
                  <Mail className="h-6 w-6 text-primary mr-4" />
                  <div>
                    <div className="font-medium">Email</div>
                    <div className="text-muted-foreground">info@csbo.com</div>
                  </div>
                </div>
                <div className="flex items-center">
                  <Phone className="h-6 w-6 text-primary mr-4" />
                  <div>
                    <div className="font-medium">Phone</div>
                    <div className="text-muted-foreground">+1 (555) 123-4567</div>
                  </div>
                </div>
                <div className="flex items-center">
                  <MapPin className="h-6 w-6 text-primary mr-4" />
                  <div>
                    <div className="font-medium">Office</div>
                    <div className="text-muted-foreground">New York, NY</div>
                  </div>
                </div>
              </div>
            </div>

            <Card>
              <CardHeader>
                <CardTitle>Send us a message</CardTitle>
                <CardDescription>
                  Fill out the form below and we'll get back to you within 24 hours.
                </CardDescription>
              </CardHeader>
              <CardContent>
                <form className="space-y-4">
                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <label className="text-sm font-medium mb-2 block">First Name</label>
                      <Input placeholder="John" />
                    </div>
                    <div>
                      <label className="text-sm font-medium mb-2 block">Last Name</label>
                      <Input placeholder="Doe" />
                    </div>
                  </div>
                  <div>
                    <label className="text-sm font-medium mb-2 block">Email</label>
                    <Input type="email" placeholder="john@example.com" />
                  </div>
                  <div>
                    <label className="text-sm font-medium mb-2 block">Inquiry Type</label>
                    <Select>
                      <SelectTrigger>
                        <SelectValue placeholder="Select inquiry type" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="issuer">Real Estate Sponsor</SelectItem>
                        <SelectItem value="investor">Private Equity Manager</SelectItem>
                        <SelectItem value="partner">Accredited Investor</SelectItem>
                        <SelectItem value="other">Other</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  <div>
                    <label className="text-sm font-medium mb-2 block">Message</label>
                    <Textarea 
                      placeholder="Tell us about your project and how we can help..."
                      rows={4}
                    />
                  </div>
                  <Button className="btn-primary w-full">
                    Send Message
                  </Button>
                </form>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-primary text-white py-12">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid md:grid-cols-4 gap-8">
            <div>
              <div className="flex items-center space-x-3 mb-4">
                <img src={csboLogo} alt="CSBO Logo" className="h-8 w-8" />
                <div>
                  <div className="text-lg font-bold">CSBO</div>
                  <div className="text-xs text-gray-300">Capital Stack Back Office</div>
                </div>
              </div>
              <p className="text-gray-300 text-sm">
                Your Capital Stack Architect™ - Building the foundation for investment success.
              </p>
            </div>
            <div>
              <h4 className="font-semibold mb-4">Services</h4>
              <ul className="space-y-2 text-sm text-gray-300">
                <li>Fund Formation</li>
                <li>Investor Onboarding</li>
                <li>Compliance Management</li>
                <li>Tax Administration</li>
              </ul>
            </div>
            <div>
              <h4 className="font-semibold mb-4">Company</h4>
              <ul className="space-y-2 text-sm text-gray-300">
                <li>About Us</li>
                <li>Our Team</li>
                <li>Careers</li>
                <li>Contact</li>
              </ul>
            </div>
            <div>
              <h4 className="font-semibold mb-4">Legal</h4>
              <ul className="space-y-2 text-sm text-gray-300">
                <li>Privacy Policy</li>
                <li>Terms of Service</li>
                <li>Compliance</li>
              </ul>
            </div>
          </div>
          <div className="border-t border-gray-600 mt-8 pt-8 text-center text-sm text-gray-300">
            <p>&copy; 2024 Capital Stack Back Office (CSBO). All rights reserved.</p>
          </div>
        </div>
      </footer>
    </div>
  )
}

export default App

